#include <iostream>

using namespace std;

/**
  * Teste as classes!!!
  **/
int main() {
    return 0;
}
