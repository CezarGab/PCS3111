#include "Competicao.h"

Competicao::Competicao(string nome, int maximoValor) :
nome(nome), maximoValor(maximoValor) {
    quantidadeDeEquipes = 0;
    equipes = new Equipe*[maximoValor];
}

Competicao::~Competicao() {
    delete[] equipes;
}

int Competicao::getQuantidadeDeEquipes() {
    return quantidadeDeEquipes;
}

int Competicao::getQuantidadeDeModalidades() {
    // Implemente o metodo
}

Equipe** Competicao::getEquipes() {
    return equipes;
}

Modalidade** Competicao::getModalidades() {
    // Implemente o metodo
}

bool Competicao::adicionar(Equipe* e) {
    if(quantidadeDeEquipes >= maximoValor) return false;
    for(int i = 0; i < quantidadeDeEquipes; i++) {
        if(equipes[i] == e) return false;
    }
    equipes[quantidadeDeEquipes] = e;
    quantidadeDeEquipes++;
    return true;
}

void Competicao::imprimir() {
    cout << "Competicao " << nome << endl;
}
