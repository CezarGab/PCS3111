/* Implemente a classe aqui */
#include "Participante.h"
Participante::Participante(string nome){
    this->nome = nome;
}

Participante::~Participante(){

}

void Participante::imprimir(){


}
