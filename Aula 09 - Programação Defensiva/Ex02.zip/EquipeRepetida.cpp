#include "EquipeRepetida.h"
#include <stdexcept>

using namespace std;


EquipeRepetida::EquipeRepetida(string mensagem) : invalid_argument(mensagem)
{

}

EquipeRepetida::~EquipeRepetida()
{
    //dtor
}
