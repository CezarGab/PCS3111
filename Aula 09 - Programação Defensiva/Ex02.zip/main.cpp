#include <iostream>

using namespace std;

/** Teste o codigo **/
int main() {
}
