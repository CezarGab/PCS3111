#include "Competicao.h"
#include <stdexcept>
#include <vector>

using namespace std;
// Implemente as alteracoes

Competicao::Competicao(string nome, int maxValor) :
nome(nome), maxValor(maxValor) {
    quantidadeDeModalidades = 0;
    quantidadeDeEquipes = 0;
    equipesVetor = new vector<Equipe*>();
    modalidades = new Modalidade*[maxValor];
}

Competicao::~Competicao() {
	delete equipesVetor;
	delete[] modalidades;
}

int Competicao::getQuantidadeDeModalidades() {
    return quantidadeDeModalidades;
}

vector<Equipe*>* Competicao::getEquipes() {
    return equipesVetor;
}

Modalidade** Competicao::getModalidades() {
    return modalidades;
}

void Competicao::adicionar(Equipe* e) {
//    if(quantidadeDeEquipes >= maxValor){
//            cout << "Vetor cheio" << endl;
//            throw new overflow_error("Equipes esta cheio"); /* Por que n�o � mais necessario verificar? */
//
//    }

    for(int i = 0; i < quantidadeDeEquipes; i++) {
        if((this->equipesVetor->at(i)) == e){
            throw new invalid_argument("Equipe ja adicionada");
        }
    }
    equipesVetor->push_back(e);

    quantidadeDeEquipes++;
}

void Competicao::adicionar(Modalidade* m) {
    if(quantidadeDeModalidades >= maxValor) throw new overflow_error("Modalidades esta cheio");
    for(int i = 0; i < quantidadeDeModalidades; i++) {
        if(modalidades[i] == m) throw new invalid_argument("Modalidade ja adicionada");
    }
    modalidades[quantidadeDeModalidades] = m;
    quantidadeDeModalidades++;
}
