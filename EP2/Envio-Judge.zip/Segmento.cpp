#include "Segmento.h"

Segmento::Segmento(int portaDeOrigem, int portaDeDestino, string dado) : portaDeOrigem(portaDeOrigem), portaDeDestino(portaDeDestino), dado(dado)
{
    //ctor
}

Segmento::~Segmento()
{
    //dtor
}

void Segmento::imprimir(){

}
