// Implemente os metodos aqui
#include <fstream>
#include "PersistenciaEquipe.h"

using namespace std;

PersistenciaEquipe::PersistenciaEquipe(string arquivo) : arquivo(arquivo) {
}

PersistenciaEquipe::~PersistenciaEquipe(){

}

void PersistenciaEquipe::inserir(Equipe *e){

    ofstream output;

    output.open(arquivo, ios_base::app);

    output << e->getNome() << endl;
    output << e->getMembros() << endl;

    output.close();
}
